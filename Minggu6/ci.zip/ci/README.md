## Praktikum
![image](https://user-images.githubusercontent.com/40889525/111038387-2904c180-845b-11eb-9012-2e3b78dc637b.png)
a. Kode 1
![image](https://user-images.githubusercontent.com/40889525/111038478-c52ec880-845b-11eb-80c0-41c6b8b8bfc6.png)
b. Kode 2
![image](https://user-images.githubusercontent.com/40889525/111038534-2c4c7d00-845c-11eb-8992-d1c34961ed06.png)
c. Kode 3
![image](https://user-images.githubusercontent.com/40889525/111038833-7f72ff80-845d-11eb-8f5f-a85ac0085d76.png)
d. Kode 4
![image](https://user-images.githubusercontent.com/40889525/111039345-2bb5e580-8460-11eb-8599-7748c8491289.png)



## Soal/Tugas
Tugas no .1
![image](https://user-images.githubusercontent.com/40889525/111060317-6fdfcf00-84ce-11eb-89a9-f03cd2b37ef5.png)
Tugas no. 2
![image](https://user-images.githubusercontent.com/40889525/111056639-32217d00-84b3-11eb-8b7e-65ee55cdf0d1.png)
Tugas no. 3
![image](https://user-images.githubusercontent.com/40889525/111057020-b9242480-84b6-11eb-85a6-ff980223e7f3.png)
Tugas no. 4
![image](https://user-images.githubusercontent.com/40889525/111058225-86caf500-84bf-11eb-812e-35042a7943c0.png)
